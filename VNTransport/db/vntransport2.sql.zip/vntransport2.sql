-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2017 at 12:41 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vntransport2`
--
CREATE DATABASE IF NOT EXISTS `vntransport2` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `vntransport2`;

-- --------------------------------------------------------

--
-- Table structure for table `businfo`
--

CREATE TABLE `businfo` (
  `ID` int(11) NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BusName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OwnerName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Service` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `Info` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `businfo`
--

INSERT INTO `businfo` (`ID`, `Email`, `Logo`, `BusName`, `OwnerName`, `Service`, `Rating`, `Info`) VALUES
(1, 'hoanglong@gmail.com', 'img/logo-hl.png', 'Hoàng Long', 'Vũ Văn Tuyến', 'Vận tải đường bộ', 4, '\nHãng xe Hoàng Long hay còn gọi là Hoàng Long Asia hoặc Hoàng Long Bus là một trong những thương hiệu xe chất lượng cao hàng đầu Việt Nam. Phục vụ hàng chục triệu hành khách Việt Nam và quốc tế trong suốt 16 năm hoạt động, xe khách Hoàng Long đã đạt giải thưởng Sao Vàng đất Việt 3 lần liên tiếp. Xe giường nằm cao cấp Hoàng Long liên tục cải tiến với rất nhiều tiện ích như TV, máy lạnh, khăn lạnh, nhà vệ sinh,... giúp hành khách trên xe luôn cảm giác thoải mái. Tất cả các lái phụ xe của nhà xe Hoàng Long đều được học giao tiếp du lịch để luôn đối xử ân cần và lịch sự đối với hành khách. Nhờ những cố gắng không ngừng, danh tiếng của Hoàng Long lan rộng khắp Việt Nam và quốc tế. Hoàng Long - Không ngừng đổi mới, không ngừng nâng cao chất lượng phục vụ.');

-- --------------------------------------------------------

--
-- Table structure for table `cmt`
--

CREATE TABLE `cmt` (
  `ID` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cmt`
--

INSERT INTO `cmt` (`ID`, `username`, `content`) VALUES
(1, 'loi', 'hang xe rat tot');

-- --------------------------------------------------------

--
-- Table structure for table `imagin`
--

CREATE TABLE `imagin` (
  `ID` int(11) NOT NULL,
  `Url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `imagin`
--

INSERT INTO `imagin` (`ID`, `Url`, `Email`) VALUES
(1, 'img/Hoanglong1.jpg', 'hoanglong@gmail.com'),
(2, 'img/Hoanglong2.jpg', 'hoanglong@gmail.com'),
(3, 'img/Hoanglong3.jpg', 'hoanglong@gmail.com'),
(4, 'img/Hoanglong4.jpg', 'hoanglong@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `urlimg` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `username`, `password`, `urlimg`) VALUES
(1, 'loi', '123', 'http://leader.pubs.asha.org/data/Journals/ASHANL/934378/NIB1_web.png'),
(2, 'huu', '321', 'http://leader.pubs.asha.org/data/Journals/ASHANL/934378/NIB1_web.png');

-- --------------------------------------------------------

--
-- Table structure for table `pricetable`
--

CREATE TABLE `pricetable` (
  `ID` int(11) NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Route` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BusType` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TripNum` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pricetable`
--

INSERT INTO `pricetable` (`ID`, `Email`, `Route`, `BusType`, `TripNum`, `Price`) VALUES
(1, 'hoanglong@gmail.com', 'Hà Nội đi Ngô Quyền', 'VIP Limousine 9 chỗ	', 25, 160000),
(2, 'hoanglong@gmail.com', 'Lê Chân đi Hà Nội', 'Ghế ngồi 45 chỗ', 18, 90000),
(3, 'hoanglong@gmail.com', 'Sài Gòn đi Cẩm Phả\n', 'Giường nằm 39 chỗ', 2, 920000),
(4, 'hoanglong@gmail.com', 'Hà Nội đi Cát Bà\n', 'Ghế ngồi 45 chỗ', 2, 220000),
(5, 'hoanglong@gmail.com', 'Cát Bà đi Hà Nội', 'Ghế ngồi 45 chỗ', 2, 200000),
(6, 'hoanglong@gmail.com', 'Lê Chân đi Sài Gòn\n', 'Giường nằm 39 chỗ', 2, 780000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `businfo`
--
ALTER TABLE `businfo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cmt`
--
ALTER TABLE `cmt`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `imagin`
--
ALTER TABLE `imagin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `pricetable`
--
ALTER TABLE `pricetable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `businfo`
--
ALTER TABLE `businfo`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cmt`
--
ALTER TABLE `cmt`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `imagin`
--
ALTER TABLE `imagin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pricetable`
--
ALTER TABLE `pricetable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
